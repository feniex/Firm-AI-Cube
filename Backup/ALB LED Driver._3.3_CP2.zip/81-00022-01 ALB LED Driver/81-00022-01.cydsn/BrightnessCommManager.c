/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/**********CHANGE LOG**********/


/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "BrightnessCommManager.h"
#include "TemperatureCommManager.h"
#include "DriverControl.h"

#define MAX_PAYLOAD_BYTE_COUNT  MAX_DRIVER_COUNT + 1
#define HEADER_BYTE_COUNT       2
#define EOP_BYTE_COUNT          2
#define MAX_PACKET_SIZE         HEADER_BYTE_COUNT + MAX_PAYLOAD_BYTE_COUNT + EOP_BYTE_COUNT

#define PACKET_TYPE_COUNT       3
#define HEADER_START_INDEX      0
#define PAYLOAD_START_INDEX     HEADER_BYTE_COUNT

#define TIMEOUT_LIMIT_IN_MILLISECONDS   500
    
/**********DEFINED CONSTANTS**********/
enum PacketState
{
    HEADER_STATE,
    PAYLOAD_STATE,
    EOP_STATE
};

/**********DATA STRUCTURES**********/
typedef struct
{
    const uint8 HEADER_BYTE;
    const uint8 PACKET_TYPE;
    const uint8 PAYLOAD_SIZE;
    const uint8 EOP_CARRIAGE_RETURN;
    const uint8 EOP_LINE_FEED;
}Packet;

static Packet PacketList[PACKET_TYPE_COUNT] = 
{
    {'~', 'B', 8, '\r', '\n'},          //Definition: Brightness, Value Range: 0x00-0xFF, Module 0(Head)-7(Kaboose)
    {'~', 'C', 9, '\r', '\n'},          //Definition: Driver Count, Payload:
                                        //Byte 0: Number of Drivers, Value Range: 1-8
                                        //Byte1-Byte8: Driver ID, Value Range: 1-8
    {'~', 'F', 8, '\r', '\n'}
};    

/**********GLOBAL VARIABLES**********/
static uint16 timerCount = 0;
static uint8 bInputTrigger = FALSE;
static uint8 bTimeoutFlag = FALSE;

/**********LOCAL FUNCTION PROTOTYPES**********/
static void detectPacket(uint8 dataByte);
static uint8 processDriverCountPacket(uint8* packet, uint8 length);
static uint8 processBrightnessPacket(uint8* packet, uint8 length, uint8 bFlashPattern);

/**********DEFINED GLOBAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: assignDriverIDs
********************************************************************************
*
* Summary:
*  Sends out the driver count packet. Only the head module executes this.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void assignDriverIDs(void)
{
    uint8 driverCountPacket[MAX_PACKET_SIZE];
    
    if(getDriverID() != HEAD_MODULE_ID)
        return;
    
    memset(driverCountPacket, 0, MAX_PACKET_SIZE);
    driverCountPacket[HEADER_START_INDEX] = PacketList[1].HEADER_BYTE;
    driverCountPacket[HEADER_START_INDEX + 1] = PacketList[1].PACKET_TYPE;
    driverCountPacket[PAYLOAD_START_INDEX + PacketList[1].PAYLOAD_SIZE]
        = PacketList[1].EOP_CARRIAGE_RETURN;
    driverCountPacket[PAYLOAD_START_INDEX + PacketList[1].PAYLOAD_SIZE + 1]
        = PacketList[1].EOP_LINE_FEED;
    driverCountPacket[PAYLOAD_START_INDEX] = 1;
    driverCountPacket[PAYLOAD_START_INDEX + 1] = HEAD_MODULE_ID;
    
    UART_LED_PutArray(driverCountPacket, MAX_PACKET_SIZE);
}

/*******************************************************************************
* Function Name: isThereInputTrigger
********************************************************************************
*
* Summary:
*  Returns edge trigger status of UART_Rx.
*
* Parameters:
*  None.
*
* Return:
*  TRUE if edge detected on UART_Rx, FALSE not detected.
*
*******************************************************************************/
uint8 isThereInputTrigger(void)
{
    return bInputTrigger;
}

/*******************************************************************************
* Function Name: clearInputTriggerFlag
********************************************************************************
*
* Summary:
*  Clears input trigger flag so that it can be set again by wakeupModule().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void clearInputTriggerFlag(void)
{
    bInputTrigger = FALSE;
}

/*******************************************************************************
* Function Name: wakeupModule
********************************************************************************
*
* Summary:
*  Called in WakeupISR, sets the flag to indicate that an edge found on UART_Rx.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void wakeupModule(void)
{
    WakeupISR_ClearPending();
    UART_Rx_ClearInterrupt();
    
    bInputTrigger = TRUE;
}

/*******************************************************************************
* Function Name: isThereTimeout
********************************************************************************
*
* Summary:
*  Returns status of CommTimeout.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
uint8 isThereTimeout(void)
{
    return bTimeoutFlag;
}

/*******************************************************************************
* Function Name: clearTimeoutFlag
********************************************************************************
*
* Summary:
*  Clears timeout flag so that it can be set again by processTimeoutTimerRoutine().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void clearTimeoutFlag(void)
{
    bTimeoutFlag = FALSE;
}

/*******************************************************************************
* Function Name: processTimeoutTimerRoutine
********************************************************************************
*
* Summary:
*  Called in CommTimeoutISR(), counts up while waiting for the next brightness
*  packet. If the timer limit is reached, then the LED is shut off and timeout
*  flag is set to put the module to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processTimeoutTimerRoutine(void)
{
    CommTimeoutISR_ClearPending();
    TimeoutTimer_ClearInterrupt(TimeoutTimer_INTR_MASK_TC);
    
    if(timerCount < TIMEOUT_LIMIT_IN_MILLISECONDS)
        timerCount++;
    else
    {
        TimeoutTimer_Stop();
        PWM_Enable_Write(FALSE);    
        timerCount = 0;
        bTimeoutFlag = TRUE;
    }
}

/*******************************************************************************
* Function Name: processBrightnessByteReceivedHandler
********************************************************************************
*
* Summary:
*  Called in UART_Out_ISR(), triggers when a byte is received from the controller.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void processBrightnessByteReceivedHandler(void)
{
    uint8 dataByte = 0;
    
    do
    {
        dataByte = UART_LED_GetChar();
        detectPacket(dataByte);
        
    }while(UART_LED_ReadRxStatus() & UART_LED_RX_STS_FIFO_NOTEMPTY);
}

/**********DEFINED LOCAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: detectPacket
********************************************************************************
*
* Summary:
*  Determines if the incoming byte belongs to a valid packet. If the packet is
*  valid, then the payload is processed.
*
* Parameters:
*  dataByte: The next byte to check in the packet
*
* Return:
*  None.
*
*******************************************************************************/
static void detectPacket(uint8 dataByte)
{
    static uint8 packet[MAX_PACKET_SIZE];   
    static enum PacketState currentState = HEADER_STATE;
    static uint8 currentPacketIndex = HEADER_START_INDEX;
    static uint8 dataTypeIndex = 0;
    uint8 loopIndex = 0;
    
    switch(currentState)
    {
        case HEADER_STATE:
            if((currentPacketIndex == HEADER_START_INDEX) &&
                (dataByte == PacketList[dataTypeIndex].HEADER_BYTE))
            {
                packet[currentPacketIndex] = dataByte;
                currentPacketIndex++;
            }
            else if(currentPacketIndex == (HEADER_START_INDEX + 1))
            {
                for(loopIndex = 0; loopIndex < PACKET_TYPE_COUNT; loopIndex++)
                {
                    if(dataByte == PacketList[loopIndex].PACKET_TYPE)
                    {
                        dataTypeIndex = loopIndex;                        
                        packet[currentPacketIndex] = dataByte;
                        currentPacketIndex++;
                        currentState = PAYLOAD_STATE;
                        break;
                    }
                }
                
                if(loopIndex >= PACKET_TYPE_COUNT)
                {
                    currentPacketIndex = HEADER_START_INDEX;
                    dataTypeIndex = 0;
                }
            }
            else
            {
                currentPacketIndex = HEADER_START_INDEX;
                dataTypeIndex = 0;
            }
            break;
        case PAYLOAD_STATE:
            packet[currentPacketIndex] = dataByte;
            currentPacketIndex++;
            
            if(currentPacketIndex >= (PAYLOAD_START_INDEX + PacketList[dataTypeIndex].PAYLOAD_SIZE))
                currentState = EOP_STATE;
            break;
        case EOP_STATE:
            if((currentPacketIndex == (PAYLOAD_START_INDEX + PacketList[dataTypeIndex].PAYLOAD_SIZE)) &&
                (dataByte == PacketList[dataTypeIndex].EOP_CARRIAGE_RETURN))
            {
                packet[currentPacketIndex] = dataByte;
                currentPacketIndex++;
            }
            else if((currentPacketIndex == (PAYLOAD_START_INDEX + PacketList[dataTypeIndex].PAYLOAD_SIZE + 1))
                    && (dataByte == PacketList[dataTypeIndex].EOP_LINE_FEED))
            {
                packet[currentPacketIndex] = dataByte;
				
				if(dataTypeIndex == 0)
                    processBrightnessPacket(packet, MAX_PACKET_SIZE - 1, FALSE);
				else if(dataTypeIndex == 1)
                    processDriverCountPacket(packet, MAX_PACKET_SIZE);
                else
                    processBrightnessPacket(packet, MAX_PACKET_SIZE - 1, TRUE);
                
                currentPacketIndex = HEADER_START_INDEX;
                currentState = HEADER_STATE;
                dataTypeIndex = 0;
            }
            else
            {
                currentPacketIndex = HEADER_START_INDEX;
                currentState = HEADER_STATE;
                dataTypeIndex = 0;
            }
            break;
    }
}

/*******************************************************************************
* Function Name: processDriverCountPacket
********************************************************************************
*
* Summary:
*  Uses packet to send an ack to the previous module, set the ID for this driver, 
*  send the packet to the next module, and start the timer to wait for an ack from
*  the next module.
*
* Parameters:
*  packet: The reference to the driver count packet to process.
*  length: The byte count for this packet.
*
* Return:
*  SUCCESS for valid inputs, FAILURE otherwise
*
*******************************************************************************/
static uint8 processDriverCountPacket(uint8* packet, uint8 length)
{
    static uint8 bReceivedCountPacket = FALSE;
    uint8 currentDriverCount = 0;
    uint8 ackPacket[MAX_PACKET_SIZE];
    uint8 countIndex = 0;
    
    if(packet == NULL || length != MAX_PACKET_SIZE)
        return FAILURE;
    
    if(bReceivedCountPacket)
        return SUCCESS;
    
    bReceivedCountPacket = TRUE;
    memcpy(ackPacket, packet, length);
    ackPacket[HEADER_START_INDEX + 1] = 'A';
    
    for(countIndex = 0; countIndex < 5; countIndex++)
        UART_Temperature_SpiUartPutArray(ackPacket, length);
    
    currentDriverCount = packet[PAYLOAD_START_INDEX] + 1;
    setIdentityByComm(currentDriverCount);
    packet[currentDriverCount + PAYLOAD_START_INDEX] = currentDriverCount;
    packet[PAYLOAD_START_INDEX] = currentDriverCount;
    setLastDriverPacket(packet, length);
    UART_LED_PutArray(packet, length);
    AckTimer_Start();
    
    return SUCCESS;
}

/*******************************************************************************
* Function Name: processBrightnessPacket
********************************************************************************
*
* Summary:
*  Uses the packet to determine the next brightness level for all modules, send the
*  packet to the next module, and start the temperature sampling timer if this module
*  is the last module in the chain.
*
* Parameters:
*  packet: The reference to the brightness packet to process.
*  length: The byte count for this packet.
*
* Return:
*  SUCCESS for valid inputs, FAILURE otherwise
*
*******************************************************************************/
static uint8 processBrightnessPacket(uint8* packet, uint8 length, uint8 bFlashPattern)
{
    static uint8 bFirstBrightnessPacket = TRUE;    
    uint8 currentBrightness = 0;
    uint8 driver_ID = 0;
    
    if(packet == NULL || length != (MAX_PACKET_SIZE - 1))
        return FAILURE;
    
    if(bFlashPattern != TRUE && bFlashPattern != FALSE)
        return FAILURE;
    
    driver_ID = getDriverID();
    if((driver_ID < HEAD_MODULE_ID) || (driver_ID > MAX_DRIVER_COUNT))
        return FAILURE;
    
    TimeoutTimer_Stop();
    
    if(bFirstBrightnessPacket)
    {
        bFirstBrightnessPacket = FALSE;           
        SamplingTimer_Start();
    }
    
    if(driver_ID == 1)
    {
        if(bFlashPattern)
            updateBrightnessLevel(packet[driver_ID + PAYLOAD_START_INDEX - 1], FALSE);
        else
        {
            currentBrightness =
                updateBrightnessLevel(packet[driver_ID + PAYLOAD_START_INDEX - 1], TRUE);
            memset(&packet[PAYLOAD_START_INDEX], currentBrightness, MAX_DRIVER_COUNT);
        }
        UART_LED_PutArray(packet, length);
    }
    else
        updateBrightnessLevel(packet[driver_ID + PAYLOAD_START_INDEX - 1], FALSE);
    
    timerCount = 0;
    TimeoutTimer_Start();
    
    return SUCCESS;
}

/* [] END OF FILE */
