/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/**********CHANGE LOG**********/


/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "BrightnessCommManager.h"
#include "TemperatureCommManager.h"
#include "DriverControl.h"
    
/**********DEFINED CONSTANTS**********/
    

/**********DATA STRUCTURES**********/


/**********GLOBAL VARIABLES**********/


/**********LOCAL FUNCTION PROTOTYPES**********/
static void initializePeripherals(void);
static void putPeripheralsToSleep(void);
static void wakeupPeripherals(void);

/**********DEFINED GLOBAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  Start of program
*
* Parameters:
*  None.
*
* Return:
*  Never returns.
*
*******************************************************************************/
int main()
{   
    uint8 bPutToSleep = FALSE;
    
    initializePeripherals();
    LED_Output_Write(TRUE);
    CyGlobalIntEnable;
    
    #if(HEAD_BOARD)
        CyDelay(250);
        setIdentityByComm(HEAD_MODULE_ID);
        assignDriverIDs();
    #endif
    
    while(!isDriverCountReceived());
    
    for(;;)
    {
        if(isThereInputTrigger())
        {
            clearInputTriggerFlag();
            if(bPutToSleep)
            {
                bPutToSleep = FALSE;
                wakeupPeripherals();
            }
        }        
        else if(isThereTimeout())
        {
            clearTimeoutFlag();
            if(!bPutToSleep)
            {
                bPutToSleep = TRUE;
                putPeripheralsToSleep();
                CySysPmDeepSleep();
            }
        }
    }
}

/**********DEFINED LOCAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: initializePeripherals
********************************************************************************
*
* Summary:
*  Sets up all peripherals needed for the project.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
static void initializePeripherals(void)
{
    UART_LED_Control_Write(TRUE);
    PWM_Enable_Write(FALSE);
    
    PWM_Start();
    PWM_WriteCompare(0);
    
    SamplingTimerISR_Start();
    ADC_SAR_Seq_Start();
    ADC_SAR_Seq_StartConvert();
    
    CommTimeoutISR_Start();
    AckTimeoutISR_Start();
    
    UART_Temp_ISR_Start();
    UART_Temperature_Start();
    
    UART_LED_ISR_Start();
    
    UART_LED_Start();
    WakeupISR_Start();
    
    LED_ISR_Start();
}

/*******************************************************************************
* Function Name: putPeripheralsToSleep
********************************************************************************
*
* Summary:
*  Saves current state/configuration of every UDB component. Needs to be called
*  before calling CySysPmDeepSleep().
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void putPeripheralsToSleep(void)
{
    UART_LED_Sleep();
    UART_Temperature_Sleep();
    
    AckTimer_Sleep();
    SamplingTimer_Sleep();
    LED_Timer_Sleep();
    TimeoutTimer_Sleep();
    
    ADC_SAR_Seq_Sleep();
    PWM_Sleep();
    
    PWM_Enable_Sleep();
    UART_LED_Control_Sleep();
}

/*******************************************************************************
* Function Name: wakeupPeripherals
********************************************************************************
*
* Summary:
*  Restores the saved state/configuration of every UDB component. Needs to be
*  called once UART_LED starts to receive data again.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void wakeupPeripherals(void)
{
    UART_LED_Wakeup();
    UART_Temperature_Wakeup();
    
    AckTimer_Wakeup();
    SamplingTimer_Wakeup();
    LED_Timer_Wakeup();
    TimeoutTimer_Wakeup();
    
    ADC_SAR_Seq_Wakeup();
    PWM_Wakeup();
    
    PWM_Enable_Wakeup();
    UART_LED_Control_Wakeup();
}

/* [] END OF FILE */
