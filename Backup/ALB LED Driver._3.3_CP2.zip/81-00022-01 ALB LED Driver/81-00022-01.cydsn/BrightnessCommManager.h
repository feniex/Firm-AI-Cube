/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/**********CHANGE LOG**********/

#ifndef BRIGHTNESS_COMM_MANAGER_H_
#define BRIGHTNESS_COMM_MANAGER_H_

/**********PREPROCESSOR DIRECTIVES**********/
#include <project.h>
    
/**********DEFINED CONSTANTS**********/
    

/**********DATA STRUCTURES**********/
    

/**********GLOBAL VARIABLES**********/
    

/**********GLOBAL FUNCTION PROTOTYPES**********/
void assignDriverIDs(void);
uint8 isThereInputTrigger(void);
void clearInputTriggerFlag(void);
void wakeupModule(void);
uint8 isThereTimeout(void);
void clearTimeoutFlag(void);
void processTimeoutTimerRoutine(void);
void processBrightnessByteReceivedHandler(void);
    
#endif
/* [] END OF FILE */
