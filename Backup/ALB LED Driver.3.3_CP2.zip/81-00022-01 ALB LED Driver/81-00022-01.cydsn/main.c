/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/**********CHANGE LOG**********/


/**********PREPROCESSOR DIRECTIVES**********/
#include "CommonVariables.h"
#include "BrightnessCommManager.h"
#include "TemperatureCommManager.h"
#include "DriverControl.h"
    
/**********DEFINED CONSTANTS**********/
    

/**********DATA STRUCTURES**********/


/**********GLOBAL VARIABLES**********/
static const uint8 CYCODE eepromBrightnessMotorPosition[4] = {0xFF, 0x00, 0x00, 0x00};   //Brightness Value, Motor Position Value, Current Board ID, Initialized Count Already 
static uint8 ramBrightnessMotorPosition[4] ={0x00,0x00,0x00,0x00};
static const uint8 bSetInitializedAlready = 1;
static uint8 driverID = 0;
static uint8 beepromCountAlreadyReset = 0;
static uint8 *peepromMemory;

uint8 stateOfLightBar = 0;
uint8 bDefaultBrightness = 0;
/**********LOCAL FUNCTION PROTOTYPES**********/
static void initializePeripherals(void);
static void wakeupPeripherals(void);
static void putPeripheralsToSleep(void);
/**********DEFINED GLOBAL FUNCTIONS**********/

void setStateOfLightBar(uint8 lightBarState)
{
    stateOfLightBar = lightBarState;
}


void clearDefaultBrightnessState(void)
{
    bDefaultBrightness = 0;
}
/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  Start of program
*
* Parameters:
*  None.
*
* Return:
*  Never returns.
*
*******************************************************************************/
int main()
{   
    uint16 countWaitForCountPacket = 0;
    uint8 bDriverCounterRecieved = FALSE;
    #if(HEAD_BOARD)
        CyDelay(200);
    #else
        CyDelay(50);  
    #endif
    CyGlobalIntEnable;
    initializePeripherals();
    EmEEPROM_Start();
    CyDelay(250);
    LED_Output_Write(FALSE);
    UART_LED_Control_Write(FALSE);
    
    //updateBrightnessLevel(0xFF, FALSE);    
    
    if(*(volatile uint8 *) &eepromBrightnessMotorPosition[3] == 0)
    {
        
        UART_LED_Control_Write(TRUE);
        
        #if(HEAD_BOARD)
            CyDelay(1000);
        #else
            CyDelay(50);  
        #endif

        #if(HEAD_BOARD)
            setIdentityByComm(HEAD_MODULE_ID);
            assignDriverIDs();
            setDriverCountReceived();
        #endif
        
        while(!isDriverCountReceived())
        {
            //if(countWaitForCountPacket>5000 && !isLastDriver())
            {
                
                //UART_LED_Control_Write(FALSE);
                //countWaitForCountPacket=0;
                //setIdentityByComm(2);
                //break;
            }
            //countWaitForCountPacket++;
            //CyDelay(1);
        } 
        ramBrightnessMotorPosition[3] = 1;
        ramBrightnessMotorPosition[2] = getDriverID();
        EmEEPROM_Write(&ramBrightnessMotorPosition[2],&eepromBrightnessMotorPosition[2],2);
    }
    else
    {
        

        peepromMemory = &eepromBrightnessMotorPosition[2];
        setIdentityByComm(*peepromMemory);
        if(getDriverID()==HEAD_MODULE_ID)
        {
            UART_LED_Control_Write(TRUE);
        }
        else
        {
            UART_LED_Control_Write(FALSE);
        }
        //TimeoutTimer_Stop();
        //AckTimer_Stop();
    }
    

    //updateBrightnessLevel(0xFF, TRUE);
    
    for(;;)
    {
        if(isThereInputTrigger() && bDefaultBrightness != 1)
        {
           clearInputTriggerFlag();
           if(isSleeping())
            { 
                clearTimeout();
                setStateOfLightBar(0);
                wakeupPeripherals();
                clearSleep();
                CyDelay(200);
            }
        }    
        if(isReadyToSendNextBrightnessPacket())
        {
            switch(stateOfLightBar)
                {
                    case 0:
                        break;
                    case 1:
                        CyDelay(200);
                        if(UART_Rx_Read() == 1 && bDefaultBrightness != 1)
                        {
                            updateBrightnessLevel(0x00, FALSE);
                            putPeripheralsToSleep();
                            setSleep();
                            CySysPmDeepSleep();
                        }
                        else
                        {
                            bDefaultBrightness = 1;
                            setStateOfLightBar(3);
                        }
                        break;
                    case 2:
                        //putSystemIntoOffState();
                    case 3:
                        //setStateOfLightBar(0);
                        //TimeoutTimer_Stop();
                        
                        clearTimeout();
                        timeoutDefaultBrightness(&eepromBrightnessMotorPosition[0]);
                        break;
                    default:
                        break;
                }
                clearIsReadyToSendNextBrightnessPacket();
            }
    }
}

/**********DEFINED LOCAL FUNCTIONS**********/
/*******************************************************************************
* Function Name: initializePeripherals
********************************************************************************
*
* Summary:
*  Sets up all peripherals needed for the project.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
static void initializePeripherals(void)
{
    UART_LED_Control_Write(TRUE);
    PWM_Enable_Write(FALSE);
    
    PWM_Start();
    PWM_WriteCompare(0);

    CommTimeoutISR_Start();
    AckTimeoutISR_Start();
    
    SamplingTimerISR_Start();
    ADC_SAR_Seq_Start();
    ADC_SAR_Seq_StartConvert();
    
    UART_Temp_ISR_Start();
    UART_Temperature_Start();
    
    UART_LED_ISR_Start();
    
    UART_LED_Start();
    WakeupISR_Start();
    
    LED_ISR_Start(); 
    
    SamplingTimer_Start();
    TimeoutTimer_Start();
}

/*******************************************************************************
* Function Name: wakeupPeripherals
********************************************************************************
*
* Summary:
*  Restores the saved state/configuration of every UDB component. Needs to be
*  called once UART_LED starts to receive data again.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void wakeupPeripherals(void)
{
    UART_LED_Wakeup();
    UART_Temperature_Wakeup();
    
    AckTimer_Wakeup();
    SamplingTimer_Wakeup();
    LED_Timer_Wakeup();
    TimeoutTimer_Wakeup();
    
    ADC_SAR_Seq_Wakeup();
    PWM_Wakeup();
    
    PWM_Enable_Wakeup();
    UART_LED_Control_Wakeup();
    EmEEPROM_Start();
    
    peepromMemory = &eepromBrightnessMotorPosition[2];
    setIdentityByComm(*peepromMemory);
    
    setIdentityByComm(*peepromMemory);
    if(getDriverID()==HEAD_MODULE_ID)
    {
        UART_LED_Control_Write(TRUE);
    }
    else
    {
        UART_LED_Control_Write(FALSE);
    }
}

void clearInitializeAlreadyEEPROM(void)
{
    static const uint8 detectedAlready = 0;
    if(beepromCountAlreadyReset == 0)
    {
        beepromCountAlreadyReset =1;
        EmEEPROM_Write(&detectedAlready,&eepromBrightnessMotorPosition[3],1);
    }
}

const uint8 * getNonVolatileBarStateMemory(void)
{
    return &eepromBrightnessMotorPosition[0];
}

uint8 * getVolatileBarStateMemory(void)
{
    return &ramBrightnessMotorPosition[0];
}

/*******************************************************************************
* Function Name: putPeripheralsToSleep
********************************************************************************
*
* Summary:
*  Saves current state/configuration of every UDB component. Needs to be called
*  before calling CySysPmDeepSleep().
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void putPeripheralsToSleep(void)
{
    UART_LED_Sleep();
    UART_Temperature_Sleep();
    
    AckTimer_Sleep();
    SamplingTimer_Sleep();
    LED_Timer_Sleep();
    TimeoutTimer_Sleep();
    
    ADC_SAR_Seq_Sleep();
    PWM_Sleep();
    
    PWM_Enable_Sleep();
    UART_LED_Control_Sleep();
}

/* [] END OF FILE */
